#include "Laplacian3d.h"

Laplacian3D_ToeplitzMatrix::Laplacian3D_ToeplitzMatrix(int rows_in, int cols_in,int arrays_in)
    : rows(rows_in),
      cols(cols_in),
      arrays(arrays_in),
      L3d_COO(rows_in * cols_in*arrays_in, rows_in * cols_in*arrays_in, 7 * rows_in * cols_in*arrays_in),
      L3d_CSR(rows_in * cols_in*arrays_in, rows_in * cols_in*arrays_in, 7 * rows_in * cols_in*arrays_in)
{
}
    
Laplacian3D_ToeplitzMatrix::~Laplacian3D_ToeplitzMatrix()
{



}


double Laplacian3D_ToeplitzMatrix::k_func(double x, double y, double z) {
    // Example variable k function; modify as needed
    return 1.0;
}

void Laplacian3D_ToeplitzMatrix::generateMatrix()
{
    // Implementation for generating the Laplacian matrix with non-homogeneous mesh spacing and variable k


    // 1.)Upper incidence matrix generation (2D)
    //     a.) Row block matrix generation
    SparseToeplitz rowBlockMatrix = SparseToeplitz(cols, cols, 3); //leaf row block matrix with 3 diagonals
    rowBlockMatrix.Diags[0] = -(cols - 1);
    rowBlockMatrix.Diags[1] = 0;
    rowBlockMatrix.Diags[2] = 1;
    rowBlockMatrix.Vals[0] = 1;
    rowBlockMatrix.Vals[1] = -1;
    rowBlockMatrix.Vals[2] = 1;

    //     b.) Identity matrix generation for upper incidence matrix
    SparseToeplitz identityMatrixRows = SparseToeplitz(rows, rows, 1); //leaf identity matrix
    identityMatrixRows.Diags[0] = 0;
    identityMatrixRows.Vals[0] = 1;

    //     c.) Identity matrix (rows) kronecker product with row block matrix
    Matrix* upperIncidenceMatrix = identityMatrixRows.Kronecker(rowBlockMatrix); // upper incidence matrix
    BlockToeplitz* rowBlockPtr = static_cast<BlockToeplitz*>(upperIncidenceMatrix);  //cast to BlockToeplitz pointer for further operations


    // 2.) Lower incidence matrix generation (2D)
    //     a.) Column block matrix generation
    SparseToeplitz columnBlockMatrix(rows, rows, 3); //leaf column block matrix with 3 diagonals
    columnBlockMatrix.Diags[0] = -(rows - 1);
    columnBlockMatrix.Diags[1] = 0;
    columnBlockMatrix.Diags[2] = 1;
    columnBlockMatrix.Vals[0] = 1;
    columnBlockMatrix.Vals[1] = -1;
    columnBlockMatrix.Vals[2] = 1;

    //     b.) Identity matrix generation for lower incidence matrix
    SparseToeplitz identityMatrixCols(cols, cols, 1); //leaf identity matrix
    identityMatrixCols.Diags[0] = 0;
    identityMatrixCols.Vals[0] = 1;

    //     c.) Column block matrix kronecker product with identity matrix (cols)
    Matrix* lowerIncidenceMatrix = columnBlockMatrix.Kronecker(identityMatrixCols); // lower incidence matrix
    BlockToeplitz* lowerIncidencePtr = static_cast<BlockToeplitz*>(lowerIncidenceMatrix);  //cast to BlockToeplitz pointer for further operations

    // 3.) Lower incidence matrix generation (3D)
    //     a.) Array block matrix generation
    SparseToeplitz arrayBlockMatrix(arrays, arrays, 3); //leaf array block matrix with 3 diagonals
    arrayBlockMatrix.Diags[0] = -(arrays - 1);
    arrayBlockMatrix.Diags[1] = 0;
    arrayBlockMatrix.Diags[2] = 1;
    arrayBlockMatrix.Vals[0] = 1;
    arrayBlockMatrix.Vals[1] = -1;
    arrayBlockMatrix.Vals[2] = 1;

    //     b.) Identity matrix generation for lower incidence matrix
    SparseToeplitz identityMatrixArrays(arrays, arrays, 1); //leaf identity matrix
    identityMatrixArrays.Diags[0] = 0;
    identityMatrixArrays.Vals[0] = 1;
    SparseToeplitz identityMatrix_2D(rows*cols, rows*cols, 1);
    identityMatrix_2D.Diags[0] = 0;
    identityMatrix_2D.Vals[0] = 1;

    //     c.) Column block matrix kronecker product with identity matrix (arrays)
    lowerIncidenceMatrix_3D = (arrayBlockMatrix.Kronecker(identityMatrix_2D))->Clone(1.0); // lower incidence matrix
    BlockToeplitz* lowerIncidencePtr_3D = static_cast<BlockToeplitz*>(lowerIncidenceMatrix_3D);  //cast to BlockToeplitz pointer for further operations
    lowerIncidenceMatrix_3D = lowerIncidencePtr_3D->Clone(1.0);

    // 4.) Final Laplacian matrix assembly
    //     a.) Concatenate upper and lower incidence matrices
    int ndiags = 2; //number of diagonals in incidence matrix
    BlockToeplitz IncidenceMatrix_2D(rows * cols * 2, rows * cols, ndiags); // incidence matrix with 2 block rows
    IncidenceMatrix_2D.Diags[0] = 0; // diagonal for upper incidence matrix
    IncidenceMatrix_2D.Diags[1] = -1; // diagonal for lower incidence matrix
    IncidenceMatrix_2D.Vals[0] = rowBlockPtr;
    IncidenceMatrix_2D.Vals[1] = lowerIncidencePtr;
    //Incidence=&IncidenceMatrix;

    //IncidenceMatrix_2D.printFullMatrix();
    upperIncidenceMatrix_3D = (identityMatrixArrays.Kronecker(IncidenceMatrix_2D))->Clone(1.0); // upper incidence matrix
    BlockToeplitz* BlockPtr_2D = static_cast<BlockToeplitz*>(upperIncidenceMatrix_3D);  //cast to BlockToeplitz pointer for further operations
    //BlockPtr_2D->printFullMatrix();
    upperIncidenceMatrix_3D = BlockPtr_2D->Clone(1.0);
    
    BlockToeplitz IncidenceMatrix_3D(rows * cols * arrays * 3, rows * cols * arrays, ndiags); // incidence matrix with 2 block rows
    IncidenceMatrix_3D.Diags[0] = 0; // diagonal for upper incidence matrix
    IncidenceMatrix_3D.Diags[1] = -1; // diagonal for lower incidence matrix
    IncidenceMatrix_3D.Vals[0] = BlockPtr_2D;
    IncidenceMatrix_3D.Vals[1] = lowerIncidencePtr_3D;

    leftIncidenceT_Matrix_3D = (upperIncidenceMatrix_3D->negativeTranspose())->Clone(1.0);
    BlockToeplitz* left_T_3D = static_cast<BlockToeplitz*>(leftIncidenceT_Matrix_3D);
    leftIncidenceT_Matrix_3D = left_T_3D->Clone(1.0);

    rightIncidenceT_Matrix_3D = (lowerIncidenceMatrix_3D->negativeTranspose())->Clone(1.0);
    BlockToeplitz* right_T_3D = static_cast<BlockToeplitz*>(rightIncidenceT_Matrix_3D);
    rightIncidenceT_Matrix_3D = right_T_3D->Clone(1.0);
    
    //     b.) Compute negative transpose
    Incidence=IncidenceMatrix_3D.Clone(1.0);
    //Incidence->printFullMatrix(); //This print also returns an error because of inconsistent block sizes
    Matrix* negTransPtr = IncidenceMatrix_3D.negativeTranspose();
    //BlockToeplitz negTrans=*negTrans;
    Incidence_T=negTransPtr;
    //BlockToeplitz* negTransBlockPtr = static_cast<BlockToeplitz*>(negTransPtr); //cast to BlockToeplitz pointer for further operations

    //     c.) W_ee matrix generation function
    int dim = 3 * rows * cols * arrays;

    DiagonalMatrix W_ee_matrix(dim);

double dx = 1.0 / cols;
double dy = 1.0 / rows;
double dz = 1.0 / arrays;

int N = cols * rows * arrays;
int Nx=cols;
int Ny=rows;
int Nz=arrays;

for (int i = 0; i < dim; ++i)
{
    int node = i % N;

    int col = node % Nx;
    int row = (node / Nx) % Ny;
    int arr = node / (Nx * Ny);

    double x = col * dx;
    double y = row * dy;
    double z = arr * dz;

    double k_val = k_func(x, y, z);

    if (i < N)
    {
        // x-directed edges
        W_ee_matrix.Diag_Vals[i] = k_val / (dx * dx);
    }
    else if (i < 2 * N)
    {
        // y-directed edges
        W_ee_matrix.Diag_Vals[i] = k_val / (dy * dy);
    }
    else
    {
        // z-directed edges
        W_ee_matrix.Diag_Vals[i] = k_val / (dz * dz);
    }
}


    Diagonal=W_ee_matrix.Clone(1.0);
    Tmp1= Vectord(Incidence->rows());
    Tmp2=Vectord(Incidence->rows());
}

void Laplacian3D_ToeplitzMatrix::Laplacian3d(const Vectord& input,Vectord& result)
{
    upperIncidenceMatrix_3D->MatMulAdd(input,0,Tmp1,0);
    lowerIncidenceMatrix_3D->MatMulAdd(input,0,Tmp1,upperIncidenceMatrix_3D->rows());
    Diagonal->MatMul(Tmp1,Tmp2);
    leftIncidenceT_Matrix_3D->MatMulAdd(Tmp2,0,result,0);
    rightIncidenceT_Matrix_3D->MatMulAdd(Tmp2,leftIncidenceT_Matrix_3D->cols(),result,0);
    for(int i=0;i<Tmp1.len();i++)
    {
        Tmp1[i]=0.0;

    }
}

inline int pmod(int a, int n)
{
    return (a % n + n) % n;
}




void Laplacian3D_ToeplitzMatrix::generate_COO_Laplacian()
{
    int Nx = cols;
    int Ny = rows;
    int Nz = arrays;

    int N   = Nx * Ny * Nz;
    int nnz = 7 * N;

    double hx = 1.0 / Nx;
    double hy = 1.0 / Ny;
    double hz = 1.0 / Nz;

    double hx2 = hx * hx;
    double hy2 = hy * hy;
    double hz2 = hz * hz;

    int q = 0;

    for (int kk = 0; kk < Nz; kk++)
    {
        double z = kk * hz;

        for (int j = 0; j < Ny; j++)
        {
            double y = j * hy;

            for (int i = 0; i < Nx; i++)
            {
                double x = i * hx;

                int row = i + Nx * (j + Ny * kk);

                int ip = pmod(i + 1, Nx);
                int im = pmod(i - 1, Nx);
                int jp = pmod(j + 1, Ny);
                int jm = pmod(j - 1, Ny);
                int kp = pmod(kk + 1, Nz);
                int km = pmod(kk - 1, Nz);

                int col_center = row;
                int col_ip = ip + Nx * (j + Ny * kk);
                int col_im = im + Nx * (j + Ny * kk);
                int col_jp = i  + Nx * (jp + Ny * kk);
                int col_jm = i  + Nx * (jm + Ny * kk);
                int col_kp = i  + Nx * (j  + Ny * kp);
                int col_km = i  + Nx * (j  + Ny * km);

                double k = k_func(x, y, z);

                double cx = k / hx2;
                double cy = k / hy2;
                double cz = k / hz2;

                L3d_COO.Array[q++] =
                    std::make_tuple(row, col_center, -2.0 * (cx + cy + cz));

                L3d_COO.Array[q++] = std::make_tuple(row, col_ip, cx);
                L3d_COO.Array[q++] = std::make_tuple(row, col_im, cx);
                L3d_COO.Array[q++] = std::make_tuple(row, col_jp, cy);
                L3d_COO.Array[q++] = std::make_tuple(row, col_jm, cy);
                L3d_COO.Array[q++] = std::make_tuple(row, col_kp, cz);
                L3d_COO.Array[q++] = std::make_tuple(row, col_km, cz);
            }
        }
    }
}

void Laplacian3D_ToeplitzMatrix::generate_CSR_Laplacian()
{
    generate_COO_Laplacian();
    L3d_CSR.COO_to_CSR(L3d_COO,L3d_CSR);
}




/*CSR Laplacian3D_ToeplitzMatrix::CSR_Laplacian()
{
    //CSR Incidence_CSR(*static_cast<BlockToeplitz*>(Incidence));
    CSR Incidence_CSR(*static_cast<BlockToeplitz*>(Incidence));
    CSR Incidence_T_CSR(*static_cast<CSR*>(Incidence_CSR.negativeTranspose()));
    DiagonalMatrix* Diag(static_cast<DiagonalMatrix*>(Diagonal));
    for(int i = 0; i<Incidence_T_CSR.rows();i++)
    {
        for(int j = Incidence_T_CSR.Rows[i]; j<Incidence_T_CSR.Rows[i+1];j++)   
        { 
            Incidence_T_CSR.Vals[j]*=sqrt(Diag->Diag_Vals[i]);
        }
    }

    int N = 7*Incidence_T_CSR.rows();

    CSR result(Incidence_T_CSR.rows(), Incidence_T_CSR.rows(), N);

    double sum;
    bool changed;
    for(int r = 0; r<Incidence_T_CSR.rows(); r++)
    {
        //printf("r = %d\n", r);
        result.Rows[r+1] = result.Rows[r];
        for(int c = 0; c<Incidence_T_CSR.rows(); c++)
        {
            //Create values on and above main diagonal
            //printf("c = %d\n", c);
            if(r<=c) 
            {
                sum = 0.0;
                changed = false;
                for(int i = Incidence_T_CSR.Rows[r]; i<Incidence_T_CSR.Rows[r+1]; i++)
                {
                    for(int j = Incidence_T_CSR.Rows[c]; j<Incidence_T_CSR.Rows[c+1]; j++)
                    {
                        if(Incidence_T_CSR.Cols[i]==Incidence_T_CSR.Cols[j])
                        {
                            if(r==9 && c==9)
                            {
                                //printf("%d\n",Incidence_T_CSR.Cols[i]);
                            }
                            sum += Incidence_T_CSR.Vals[j]*Incidence_T_CSR.Vals[i];
                            changed = true;
                            break;
                        }
                    }
                }
                if(changed==true)
                {
                    result.Vals[result.Rows[r+1]] = -sum;
                    result.Cols[result.Rows[r+1]] = c;
                    result.Rows[r+1]++;
                    //break;
                }
            }
            //Check for pre-existing values due to symmetry, insert values below main diagonal
            else
            {
                for(int i = 0; i<r; i++) 
                {   
                    for(int j = result.Rows[c]; j<result.Rows[c+1];j++)
                    {
                        if(r == result.Cols[j] && c == i)
                        {
                            result.Vals[result.Rows[r+1]] = result.Vals[j];
                            result.Cols[result.Rows[r+1]] = i;
                            result.Rows[r+1]++;
                            break;
                        }
                    }
                }
            }
        }
    }
    
    return result;
}

COO Laplacian3D_ToeplitzMatrix::COO_Laplacian()
{
    //COO Incidence_COO(*static_cast<BlockToeplitz*>(Incidence));
    COO Incidence_COO(*static_cast<BlockToeplitz*>(Incidence));
    COO Incidence_T_COO(*static_cast<COO*>(Incidence_COO.negativeTranspose()));
    DiagonalMatrix* Diag(static_cast<DiagonalMatrix*>(Diagonal));
    for(int i = 0; i<Incidence_T_COO.Num_Vals;i++)
    {
        std::get<2>(Incidence_T_COO.Array[i])*=sqrt(Diag->Diag_Vals[std::get<0>(Incidence_T_COO.Array[i])]);
    }

    int N=7*Incidence_T_COO.rows();

    COO result(Incidence_T_COO.rows(), Incidence_T_COO.rows(), N);

    int n = 0;
    double sum;
    bool changed;
    for(int r = 0; r<Incidence_T_COO.rows(); r++)
    {
        //printf("r=%d\n",r);
        for(int c = 0; c<Incidence_T_COO.rows(); c++)
        {
            //printf("c=%d\n",c);
            //Create values on and above main diagonal
            if(r<=c) 
            {
                changed=false;
                sum = 0.0;
                for(int i = 0; i<Incidence_T_COO.Num_Vals; i++) 
                //i was suupposed to start from k to avoid unnecessary steps, but something went wrong
                {
                    if(r == std::get<0>(Incidence_T_COO.Array[i]))
                    {
                        for(int j = i; j<Incidence_T_COO.Num_Vals; j++)
                        {
                            if(c == std::get<0>(Incidence_T_COO.Array[j]) 
                                && std::get<1>(Incidence_T_COO.Array[i])==std::get<1>(Incidence_T_COO.Array[j]))
                            {
                                sum += std::get<2>(Incidence_T_COO.Array[j])*std::get<2>(Incidence_T_COO.Array[i]);
                                changed= true;
                                break;
                            }
                            if(c<std::get<0>(Incidence_T_COO.Array[j]))
                            {
                                break;
                            }
                        }
                    }
                    if(r<std::get<0>(Incidence_T_COO.Array[i]))
                    {
                        if(changed==true)
                        {
                            std::get<2>(result.Array[n]) = -sum;
                            std::get<0>(result.Array[n]) = r;
                            std::get<1>(result.Array[n]) = c;
                            n++;
                        }
                        break;
                    }
                }
            }
            //Check for pre-existing values due to symmetry, insert values below main diagonal
            else
            {
                for(int i = 0; i<n; i++) 
                {   
                    if(r == std::get<1>(result.Array[i]) && c == std::get<0>(result.Array[i]))
                    {
                        std::get<1>(result.Array[n]) = std::get<0>(result.Array[i]);
                        std::get<0>(result.Array[n]) = std::get<1>(result.Array[i]);
                        std::get<2>(result.Array[n]) = std::get<2>(result.Array[i]);
                        n++;
                    }
                }
            }
        }
    }
    //Set last value
    if(changed==true)
        {
            std::get<2>(result.Array[n]) = -sum;
            std::get<0>(result.Array[n]) = Incidence_T_COO.rows()-1;
            std::get<1>(result.Array[n]) = Incidence_T_COO.rows()-1;
            n++;
        }
    return result;
}*/