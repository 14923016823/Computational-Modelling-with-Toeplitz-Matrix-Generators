#include "ForwardEuler.h"

ForwardEulerSolver::ForwardEulerSolver(Laplacian2D_ToeplitzMatrix& lap)
    : L(lap)
{}

void ForwardEulerSolver::solve(Vectord& u, double dt, int numSteps) const
{
    L.generateMatrix();
    Vectord Lu(u.len());
    toeploop( u, Lu,  dt, numSteps);


}

void ForwardEulerSolver::solvecoo(Vectord& u, double dt, int numSteps) const
{
    L.generate_COO_Laplacian();
    Vectord Lu(u.len());
    cooloop( u, Lu,  dt, numSteps);
}

void ForwardEulerSolver::solvecsr(Vectord& u, double dt, int numSteps) const
{
    L.generate_CSR_Laplacian();
    Vectord Lu(u.len());
    csrloop( u, Lu,  dt, numSteps);
    //auto start=std::chrono::high_resolution_clock::now();

    //auto end=std::chrono::high_resolution_clock::now();
    //auto microsec=std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    //return microsec.count();
}

void ForwardEulerSolver::csrloop(Vectord& u,Vectord& Lu, double dt, int numSteps) const
{
    for (int step = 0; step < numSteps; ++step)
    {
        L.L2d_CSR.MatMul(u, Lu);    // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }

}

void ForwardEulerSolver::cooloop(Vectord& u,Vectord& Lu, double dt, int numSteps) const
{
    for (int step = 0; step < numSteps; ++step)
    {
        L.L2d_COO.MatMul(u, Lu);    // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }

}

void ForwardEulerSolver::toeploop(Vectord& u,Vectord& Lu, double dt, int numSteps) const
{
    for (int step = 0; step < numSteps; ++step)
    {
        L.Laplacian2d(u, Lu);    // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }

}

