#pragma once
#include "Laplacian2d.h"
#include <fstream>
#include <string>

class ForwardEulerSolver {
public:
    ForwardEulerSolver(Laplacian2D_ToeplitzMatrix& lap);

    void solve(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;
    void solvecsr(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;
    void solvecoo(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;

private:
    void csrloop(Vectord& u,Vectord& Lu, double dt, int numStep) const;
    void cooloop(Vectord& u,Vectord& Lu, double dt, int numStep) const;
    void toeploop(Vectord& u,Vectord& Lu, double dt, int numStep) const;
     Laplacian2D_ToeplitzMatrix& L;
};
