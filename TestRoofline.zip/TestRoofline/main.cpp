#include "main.h"

void initializeGaussian3D(
    Vectord& state,
    int h,//rows
    int w,//cols
    int d,//arrays
    double amplitude,
    double sigma
)
{
    double ic = 0.5 * (h - 1);
    double jc = 0.5 * (w - 1);
    double kc = 0.5 * (d - 1);

    double twoSigma2 = 2.0 * sigma * sigma;

    for (int k = 0; k < d; ++k)
    {
        for (int i = 0; i < h; ++i)
        {
            for (int j = 0; j < w; ++j)
            {
                double di = i - ic;
                double dj = j - jc;
                double dk = k - kc;

                double r2 = di * di + dj * dj + dk * dk;

                int idx = j + w * (i + h * k);
                state[idx] = amplitude * std::exp(-r2 / twoSigma2);
            }
        }
    }
}


void writeVector3DToFile(
    const Vectord& vec,
    int rows,
    int cols,
    int arrays,
    const std::string& filename
)
{
    std::ofstream file(filename);
    if (!file.is_open())
        throw std::runtime_error("Could not open file");

    for (int z = 0; z < arrays; ++z)
    {
        file << "# z = " << z << "\n";

        for (int y = 0; y < rows; ++y)
        {
            for (int x = 0; x < cols; ++x)
            {
                int i = x + cols * (y + rows * z);
                file << vec[i] << " ";
            }
            file << "\n";
        }
        file << "\n";
    }

    file.close();
}

void initializeGaussian(Vectord& state,int h,int w,double amplitude,double sigma)
{
    double ic = 0.5 * (h - 1);
    double jc = 0.5 * (w - 1);

    double twoSigma2 = 2.0 * sigma * sigma;

    for (int i = 0; i < h; i++)
    {
        for (int j = 0; j < w; j++)
        {
            double di = i - ic;
            double dj = j - jc;

            double r2 = di * di + dj * dj;
            state[i * w + j] =
                amplitude * std::exp(-r2 / twoSigma2);
        }
    }
}
void writeStateToFile(
    const std::string& filename,
    const Vectord& state,
    int h,
    int w
)
{
    if (state.len() != static_cast<std::size_t>(h * w))
        throw std::invalid_argument("State size does not match h * w");

    std::ofstream out(filename);
    if (!out)
        throw std::runtime_error("Failed to open output file");

    out.precision(16);
    out.setf(std::ios::scientific);

    // Write as a single column vector (lexicographic order)
    for (std::size_t i = 0; i < state.len(); ++i)
        out << state[i] << '\n';

    out.close();
}

void TestLaplacian2d(int size)
{


    int rows = size;
    int cols = size;


    Vectord vec(cols*rows);

    initializeGaussian(vec, rows, cols, 2.0, 10.0);


    Laplacian2D_ToeplitzMatrix L2d=Laplacian2D_ToeplitzMatrix(rows,cols);
    //std::cout<<"calculating";
    
    ForwardEulerSolver solver=ForwardEulerSolver(L2d);

    solver.solve(vec,1e-5,10);


}

int64_t TestLaplacian3d(int size)
{
    int rows = 50;
    int cols = 50;
    int arrays = 50;
    Vectord vec1(cols*rows*arrays);
    Vectord vec2(cols*rows*arrays);
    initializeGaussian3D(vec1, rows, cols,arrays, 2.0, 10.0);
    initializeGaussian3D(vec2, rows, cols,arrays, 2.0, 10.0);
    Laplacian3D_ToeplitzMatrix L3d=Laplacian3D_ToeplitzMatrix(rows,cols,arrays);
    ForwardEulerSolver3d solver=ForwardEulerSolver3d(L3d);

    auto microsec1=solver.solve(vec1,1e-6,10);

    return microsec1;

    
}



int main() 
{
    TestLaplacian2d(2000);
    return 0;
}


