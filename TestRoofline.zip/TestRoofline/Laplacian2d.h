#pragma once
#include "BlockToeplitz.h"
#include "DiagonalMatrix.h"
#include "COO.h"
#include "CSR.h"

class Laplacian2D_ToeplitzMatrix{
    public:

    Laplacian2D_ToeplitzMatrix(const int rows_in, const int cols_in);

    ~Laplacian2D_ToeplitzMatrix();

    
    void generateMatrix();
    void generate_COO_Laplacian();
    void generate_CSR_Laplacian();

    void Laplacian2d(const Vectord& x,Vectord& result);



    COO L2d_COO;
    CSR L2d_CSR;

    
    private:
    int rows,cols;

    Matrix* Incidence; //the geometry of the problem
    Matrix* Diagonal;//This matrix encapsulates grid spacing and variable k
    Matrix* Incidence_T;//negative transpose of incidence matrix

    double k_func(double x, double y);    
    
    Vectord Tmp1;
    Vectord Tmp2;

    //Vectord generateMatrix(const int rows, const int cols, Vectord& b1);
};
