#include "ForwardEuler3d.h"

ForwardEulerSolver3d::ForwardEulerSolver3d(Laplacian3D_ToeplitzMatrix& lap)
    : L(lap)
{}

uint64_t ForwardEulerSolver3d::solve(Vectord& u, double dt, int numSteps) const
{
    L.generateMatrix();
    Vectord Lu(u.len());
    
    auto start=std::chrono::high_resolution_clock::now();

    for (int step = 0; step < numSteps; ++step)
    {
        L.Laplacian3d(u, Lu);      // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }
    auto end=std::chrono::high_resolution_clock::now();
    auto microsec=std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    return microsec.count();
}

uint64_t ForwardEulerSolver3d::solvecoo(Vectord& u, double dt, int numSteps) const
{
    L.generate_COO_Laplacian();
    Vectord Lu(u.len());

    auto start=std::chrono::high_resolution_clock::now();
    for (int step = 0; step < numSteps; ++step)
    {
        L.L3d_COO.MatMul(u, Lu);      // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }
    auto end=std::chrono::high_resolution_clock::now();
    auto microsec=std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    return microsec.count();
}

uint64_t ForwardEulerSolver3d::solvecsr(Vectord& u, double dt, int numSteps) const
{
    L.generate_CSR_Laplacian();
    Vectord Lu(u.len());
    
    auto start=std::chrono::high_resolution_clock::now();
    for (int step = 0; step < numSteps; ++step)
    {
        L.L3d_CSR.MatMul(u, Lu);    // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }
    auto end=std::chrono::high_resolution_clock::now();
    auto microsec=std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    return microsec.count();
}


