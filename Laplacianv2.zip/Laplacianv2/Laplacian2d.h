#pragma once
#include "BlockToeplitz.h"
#include "DiagonalMatrix.h"
#include "COO.h"
#include "CSR.h"

class Laplacian2D_ToeplitzMatrix{
    public:

    Laplacian2D_ToeplitzMatrix(const int rows_in, const int cols_in);

    ~Laplacian2D_ToeplitzMatrix();

    
    void Generate_Toeplitz();
    void Generate_CSR();
    void Generate_COO();

    void Laplacian_Toeplitz(const Vectord& x,Vectord& result);
    void Laplacian_CSR(const Vectord& x,Vectord& result);
    void Laplacian_COO(const Vectord& x,Vectord& result);


    
    private:
    int rows,cols;

    COO* I_COO;
    COO* I_T_COO;
    CSR* I_CSR;
    CSR* I_T_CSR;

    BlockToeplitz* Incidence; //the geometry of the problem
    DiagonalMatrix* Diagonal;//This matrix encapsulates grid spacing and variable k
    BlockToeplitz* Incidence_T;//negative transpose of incidence matrix

    double k_func(double x, double y);    
    
    Vectord Tmp1;//Temporary vectors used in Laplacian calculations
    Vectord Tmp2;

    //Vectord generateMatrix(const int rows, const int cols, Vectord& b1);
};
