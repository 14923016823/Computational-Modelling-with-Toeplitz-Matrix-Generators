#pragma once
#include "Laplacian3d.h"
#include<chrono>

class ForwardEulerSolver3d {
public:
    ForwardEulerSolver3d(Laplacian3D_ToeplitzMatrix& lap);

    uint64_t solveToeplitz(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;
    uint64_t solveCSR(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;
    uint64_t solveCOO(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;

private:
     Laplacian3D_ToeplitzMatrix& L;
};
