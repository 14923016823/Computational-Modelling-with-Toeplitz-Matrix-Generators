#pragma once
#include "Laplacian2d.h"
#include<chrono>
#include <fstream>
#include <string>

class ForwardEulerSolver {
public:
    ForwardEulerSolver(Laplacian2D_ToeplitzMatrix& lap);

    uint64_t solveToeplitz(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;
    uint64_t solveCSR(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;
    uint64_t solveCOO(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;

private:
     Laplacian2D_ToeplitzMatrix& L;
};
