#pragma once

#include <vector>
#include <stdexcept>
#include <iostream>
#include "Matrix.h"
#include "VectorD.h"

class DiagonalMatrix : public Matrix 
{
public:

    double* Diag_Vals;
    DiagonalMatrix(int size);

    DiagonalMatrix(int nrows, int ncols);

    ~DiagonalMatrix(); 
      
    //copy and scale constructor
    DiagonalMatrix(DiagonalMatrix& other,double c);

    // scalar multiplication
    void operator*=(double c) override;
    
    // matrix-vector multiplication (fast)
    Vectord operator*(Vectord& vec) override;
    
    //Returns a cloned and scaled version
    Matrix* Clone(double c) override;

    void MatMulAdd(const Vectord& x,const int x_start,Vectord& result,const int result_start) override;
    void MatMul(const Vectord& x,Vectord& result) override;
   

    Matrix* Kronecker(Matrix&) override;

    Matrix* negativeTranspose();

    void printFullMatrix() override;
    
    double operator()(int i, int j) const override;
};

