#pragma once

#include "Matrix.h"
#include "VectorD.h"
#include "SparseToeplitz.h"

class BlockToeplitz: public Matrix
{
public:
    int Num_Diags;
    int* Diags;
    MatrixPointer* Vals;       //sub-Toeplitz matrices (only if recursive)

    // constructor
    BlockToeplitz(int nrows, int ncols, int ndiags);

    //copy and scale constructor
    BlockToeplitz(BlockToeplitz& other, double c);
    ~BlockToeplitz(); 

    Vectord operator*(Vectord& vec) override;
   

    void operator*=(double c) override;
    void MatMulAdd(const Vectord& x,const int x_start,Vectord& result,const int result_start) override;
    void MatMul(const Vectord& x,Vectord& result) override;
    

    Matrix* Kronecker(Matrix& B) override;

    //Returns a cloned and scaled version of 
    Matrix* Clone(double c) override;
   
    Matrix* negativeTranspose() override;

    void printFullMatrix() override;

    double operator()(int i, int j) const override;
};

