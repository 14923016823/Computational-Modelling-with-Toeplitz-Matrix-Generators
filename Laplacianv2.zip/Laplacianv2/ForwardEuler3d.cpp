#include "ForwardEuler3d.h"

ForwardEulerSolver3d::ForwardEulerSolver3d(Laplacian3D_ToeplitzMatrix& lap)
    : L(lap)
{}

uint64_t ForwardEulerSolver3d::solveToeplitz(Vectord& u, double dt, int numSteps) const
{
    
    L.Generate_Toeplitz();

    Vectord Lu(u.len());
    
    
    auto start=std::chrono::high_resolution_clock::now();
    for (int step = 0; step < numSteps; ++step)
    {
        L.Laplacian_Toeplitz(u, Lu);      // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }
    auto end=std::chrono::high_resolution_clock::now();
    auto microsec=std::chrono::duration_cast<std::chrono::microseconds>(end - start);

    return microsec.count();
}

uint64_t ForwardEulerSolver3d::solveCOO(Vectord& u, double dt, int numSteps) const
{
    
    L.Generate_COO();

    Vectord Lu(u.len());
    
    
    auto start=std::chrono::high_resolution_clock::now();
    for (int step = 0; step < numSteps; ++step)
    {
        L.Laplacian_COO(u, Lu);      // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }
    auto end=std::chrono::high_resolution_clock::now();
    auto microsec=std::chrono::duration_cast<std::chrono::microseconds>(end - start);

    return microsec.count();
}

uint64_t ForwardEulerSolver3d::solveCSR(Vectord& u, double dt, int numSteps) const
{
    
    L.Generate_CSR();

    Vectord Lu(u.len());
    
    
    auto start=std::chrono::high_resolution_clock::now();
    for (int step = 0; step < numSteps; ++step)
    {
        L.Laplacian_CSR(u, Lu);      // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }
    auto end=std::chrono::high_resolution_clock::now();
    auto microsec=std::chrono::duration_cast<std::chrono::microseconds>(end - start);

    return microsec.count();
}


