#pragma once

#include "BlockToeplitz.h"
#include "DiagonalMatrix.h"
#include "COO.h"
#include "CSR.h"

class Laplacian3D_ToeplitzMatrix{
    public:

    Laplacian3D_ToeplitzMatrix(const int rows, const int cols, const int arrays);

    ~Laplacian3D_ToeplitzMatrix();

    void Generate_Toeplitz();
    void Generate_CSR();
    void Generate_COO();

    void Laplacian_Toeplitz(const Vectord& x,Vectord& result);
    void Laplacian_CSR(const Vectord& x,Vectord& result);
    void Laplacian_COO(const Vectord& x,Vectord& result);

    void generate_COO_Laplacian();
    void generate_CSR_Laplacian();
    //COO L3d_COO;
    //CSR L3d_CSR;
    
    //private:
    //Matrix* Incidence; //the geometry of the problem
    BlockToeplitz* upperIncidenceMatrix_3D;
    BlockToeplitz* lowerIncidenceMatrix_3D;
    DiagonalMatrix* Diagonal;//This matrix encapsulates grid spacing and variable k
    //Matrix* Incidence_T;//negative transpose of incidence matrix
    BlockToeplitz* leftIncidenceT_Matrix_3D;
    BlockToeplitz* rightIncidenceT_Matrix_3D;

    COO* U_I_3D_COO;//upper incidence
    COO* L_I_3D_COO;//lower incidence
    COO* L_I_T_3D_COO;//left incidence transpose negative
    COO* R_I_T_3D_COO; //right incidence negative transpose

    CSR* U_I_3D_CSR;//upper incidence
    CSR* L_I_3D_CSR;//lower incidence
    CSR* L_I_T_3D_CSR;//left incidence transpose negative
    CSR* R_I_T_3D_CSR; //right incidence negative transpose

    double k_func(double x, double y, double z);
    int rows;
    int cols;
    int arrays;    

    Vectord Tmp1;
    Vectord Tmp2;

    //Vectord generateMatrix(const int rows, const int cols, Vectord& b1);
};
