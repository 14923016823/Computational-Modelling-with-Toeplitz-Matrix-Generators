#pragma once

#include <fstream>
#include <string>
#include <cmath>
#include<chrono>
#include "Laplacian2d.h"
#include "Laplacian3d.h"
#include "ForwardEuler.h"
#include "ForwardEuler3d.h"
//#include "Laplacian2d_CSR.h"
//#include "Laplacian2d_COO.h"