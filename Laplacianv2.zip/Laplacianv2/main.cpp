#include "main.h"



void initializeGaussian3D(
    Vectord& state,
    int h,//rows
    int w,//cols
    int d,//arrays
    double amplitude,
    double sigma
)
{
    double ic = 0.5 * (h - 1);
    double jc = 0.5 * (w - 1);
    double kc = 0.5 * (d - 1);

    double twoSigma2 = 2.0 * sigma * sigma;

    for (int k = 0; k < d; ++k)
    {
        for (int i = 0; i < h; ++i)
        {
            for (int j = 0; j < w; ++j)
            {
                double di = i - ic;
                double dj = j - jc;
                double dk = k - kc;

                double r2 = di * di + dj * dj + dk * dk;

                int idx = j + w * (i + h * k);
                state[idx] = amplitude * std::exp(-r2 / twoSigma2);
            }
        }
    }
}


void writeVector3DToFile(
    const Vectord& vec,
    int rows,
    int cols,
    int arrays,
    const std::string& filename
)
{
    std::ofstream file(filename);
    if (!file.is_open())
        throw std::runtime_error("Could not open file");

    for (int z = 0; z < arrays; ++z)
    {
        file << "# z = " << z << "\n";

        for (int y = 0; y < rows; ++y)
        {
            for (int x = 0; x < cols; ++x)
            {
                int i = x + cols * (y + rows * z);
                file << vec[i] << " ";
            }
            file << "\n";
        }
        file << "\n";
    }

    file.close();
}

void initializeGaussian(Vectord& state,int h,int w,double amplitude,double sigma)
{
    double ic = 0.5 * (h - 1);
    double jc = 0.5 * (w - 1);

    double twoSigma2 = 2.0 * sigma * sigma;

    for (int i = 0; i < h; i++)
    {
        for (int j = 0; j < w; j++)
        {
            double di = i - ic;
            double dj = j - jc;

            double r2 = di * di + dj * dj;
            state[i * w + j] =
                amplitude * std::exp(-r2 / twoSigma2);
        }
    }
}
void writeStateToFile(
    const std::string& filename,
    const Vectord& state,
    int h,
    int w
)
{
    if (state.len() != static_cast<std::size_t>(h * w))
        throw std::invalid_argument("State size does not match h * w");

    std::ofstream out(filename);
    if (!out)
        throw std::runtime_error("Failed to open output file");

    out.precision(16);
    out.setf(std::ios::scientific);

    // Write as a single column vector (lexicographic order)
    for (std::size_t i = 0; i < state.len(); ++i)
        out << state[i] << '\n';

    out.close();
}

long TestLaplacian2d(int size)
{
    //std::cout<<size\n;

    int rows = size;
    int cols = size;


   // Vectord vec1(cols*rows);
    Vectord vec2(cols*rows);
    //initializeGaussian(vec1, rows, cols, 2.0, 10.0);
    initializeGaussian(vec2, rows, cols, 2.0, 10.0);
    //std::cout<<"writing start to file";
    //writeStateToFile("start_state.dat", vec, rows, cols);

    //Laplacian2D_FullMatrix laplacian(rows, cols);
    //std::cout<<"generating matries";

    Laplacian2D_ToeplitzMatrix L2d=Laplacian2D_ToeplitzMatrix(rows,cols);
    ForwardEulerSolver solver=ForwardEulerSolver(L2d);


    //auto microsec2=solver.solve(vec1,1e-5,1000);
    auto microsec=solver.solveCOO(vec2,1e-5,1);


    //writeStateToFile("end_state.dat", vec, rows, cols);

    return microsec;
}

int64_t TestLaplacian3d(int size)
{
    int rows = size;
    int cols = size;
    int arrays = size;
    Vectord vec1(cols*rows*arrays);
    //Vectord vec2(cols*rows*arrays);
    initializeGaussian3D(vec1, rows, cols,arrays, 2.0, 10.0);
    //initializeGaussian3D(vec2, rows, cols,arrays, 2.0, 10.0);
    Laplacian3D_ToeplitzMatrix L3d=Laplacian3D_ToeplitzMatrix(rows,cols,arrays);
    ForwardEulerSolver3d solver=ForwardEulerSolver3d(L3d);

    auto microsec1=solver.solveToeplitz(vec1,1e-6,1);

    return microsec1;

    
}


void run_and_save(int minsize, int power, const char* filename) {
    int count = power;
    long* times = new long[count];
    int* sizes = new int[count];

    // fill array
    for (int i = 0; i < power; i++) 
    {
        int size=minsize*pow(2,i);

        long tim = TestLaplacian2d(size);    // microsec
        std::cout << size<<":"<<tim << "\n";
        times[i] = tim;
        sizes[i]=size;         

    }

    // write "size time_ns" per line
    std::ofstream out(filename);
    if (!out) {
        std::cerr << "Could not open file " << filename << "\n";
        delete[] times;
        return;
    }

    for (int idx = 0; idx < count; ++idx) 
    {
        out << sizes[idx] << " " << times[idx] << "\n";
    }

    out.close();
    delete[] times;
}

int main() 
{
    //long a=TestLaplacian3d(10);
    //printf("%d",a);

    run_and_save(5, 12, "2d_COO.txt");
    return 0;
}

