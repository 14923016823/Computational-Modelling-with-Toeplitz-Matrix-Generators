#include "COO.h"

COO::COO(int num_rows, int num_cols, int num_vals)
{
    Num_Vals = num_vals;
    Array = new tuple[Num_Vals];
    Num_Rows = num_rows;
    Num_Cols = num_cols;
    for(int q = 0;q<num_vals;q++)
        Array[q] = std::make_tuple(0,0,0);
}

COO::COO(int num_rows, int num_cols, const std::initializer_list<tuple>& list)
: COO(num_rows, num_cols, (int)list.size())
{
    std::uninitialized_copy(list.begin(), list.end(), Array);
}



void COO::MatMulAdd(const Vectord& x,const int x_start,Vectord& result,const int result_start)
{
    double res_i;
    for(int i=0;i<Num_Vals;i++)
    {
        res_i = std::get<2>(Array[i])*x[std::get<1>(Array[i])+x_start];
        //#pragma omp atomic update
        result[std::get<0>(Array[i])+result_start] += res_i;
    }

};
void COO::MatMul(const Vectord& x,Vectord& result)
{
    if(x.len()!=Num_Cols||result.len()!=Num_Rows)
    {
        throw std::invalid_argument("Vector and Matrix size dont match COO");
    }
    for(int i=0;i<result.len();i++)
    {
        result[i]=0.0;
    }
    MatMulAdd(x,0,result,0);
}



Vectord COO::operator*(Vectord& vect)
{
    int len = vect.len();
    if (len != Num_Cols) 
    {
        throw std::invalid_argument("Vector and Matrix size don't match");
    }
    Vectord result(Num_Rows);
    //double value;
    //int row_ind;
    //int col_ind;
    //int i;
    //#pragma omp parallel for //private(i, row_ind, col_ind, value)
    for(int i=0;i<Num_Vals;i++)
    {
        double res_i = std::get<2>(Array[i])*vect.Vec[std::get<1>(Array[i])];
        //#pragma omp atomic update
        result.Vec[std::get<0>(Array[i])] += res_i;
        //printf("i = %d\n",i);
    }
    return result;
}

COO::~COO()
{ 
    delete[] Array;
    Array = nullptr;
}

void COO::print()
{
    std::cout << '[';
    for(int i=0;i<Num_Vals;i++)
    {
        std::cout << '(' << std::get<0>(Array[i]) << ", "
                            << std::get<1>(Array[i]) << ", "
                            << std::get<2>(Array[i]) << ')';
    }
    std::cout << ']' << std::endl;
}

COO::COO(SparseToeplitz& ST)
{
    Num_Vals = 0;
    Num_Rows = ST.rows();
    Num_Cols = ST.cols();

    //Determine number of non-zero values
    for(int q = 0; q<ST.Num_Diags;q++)
    {
        int f = ST.Diags[q];
        if(f==0)
        {
            Num_Vals += std::min(Num_Cols,Num_Rows);
        }
        else if(f>0)
        {
            Num_Vals += Num_Cols-f;
        }
        else 
        {
            Num_Vals += Num_Rows+f;
        }
    }

    Array = new tuple[Num_Vals];
    int c = 0;

    //Fill Array with correct tuples
    for(int i=0;i<Num_Rows;i++)
    {
        for(int j = 0;j<ST.Num_Diags;j++)
        {
            if(Num_Cols > ST.Diags[j]+i && ST.Diags[j]+i >= 0)
            {
                Array[c] = std::make_tuple(i,ST.Diags[j]+i,ST.Vals[j]);
                c++;
            }
        }
    }
}

void COO::operator*=(double c) 
{
    int i;
    //#pragma omp parallel for private(i)
    for (i=0;i<Num_Vals;i++)
    {
        std::get<2>(Array[i])*=c;
    }
}

COO::COO(COO& other,double c)
{

    Num_Rows=other.Num_Rows;
    Num_Cols=other.Num_Cols;
    Num_Vals=other.Num_Vals;
    Array = new tuple[Num_Vals];
    int i;
    //#pragma omp parallel for private(i)
    for(i=0;i<Num_Vals;i++)
    {
        std::get<0>(Array[i])=std::get<0>(other.Array[i]);
        std::get<1>(Array[i])=std::get<1>(other.Array[i]);
        std::get<2>(Array[i])=std::get<2>(other.Array[i])*c;
    }

}

double COO::operator()(int i, int j) const
{
    if (i < 0 || i >= Num_Rows || j < 0 || j >= Num_Cols)
    {
        throw std::invalid_argument("Index outside of matrix boundaries");
    }
    for (int d = 0; d < Num_Vals; ++d) 
    {
        if (std::get<0>(Array[d]) == i && std::get<1>(Array[d]) == j)
            return std::get<2>(Array[d]);
    }
    return 0.0;
}

Matrix* COO::Clone(double c)
{
   return new COO(*this, c);
}

Matrix* COO::Kronecker(Matrix& B)
{
   throw std::invalid_argument("Kronecker product not impemented for COO");
}

Matrix* COO::negativeTranspose()
{ //This seems very inefficient, but I do not know how to get it working otherwise
    COO* negTrans = new COO(Num_Cols, Num_Rows, Num_Vals);
    int Rows[Num_Cols+1]; //Array to count entries per row in transposed matrix
    for(int j=0;j<Num_Cols+1;j++)
        Rows[j] = 0;
//#pragma omp parallel for
    for(int c=0;c<Num_Cols;c++) //Go through columns of original matrix
    {
        for(int i=0;i<Num_Vals;i++) //Go through values
        {
            if(c==std::get<1>(Array[i])) //Check whether current value is in current column
            {
                Rows[c+1]++;
                //std::cout << c << '\n';
            }
        }
    }
    for(int c = 0;c<Num_Cols;c++)
    {
        Rows[c+1] += Rows[c];
        //std::cout << Rows[c+1] << '\n';
    }

    int n;
    //#pragma omp parallel for private(n)
    for(int c=0;c<Num_Cols;c++) //Cols of original matrix, so rows of transposed matrix
    {
        n=Rows[c];
        //printf("%d\n",c);
        //for(int r=0;r<Num_Rows/block_rows;r++) //Rows of original matrix, so cols of transposed matrix
        //{   
            //printf("r = %d\n",r);
            for(int i=0;i<Num_Vals;i++) //Loop over values in current row
            {
                //printf("c=%d, i=%d\n",c, i);
                //printf("%d\n",n);
                if(c==std::get<1>(Array[i]) && n<Rows[c+1])
                {
                    //printf("yes, c=%d, i=%d, n=%d\n",c, i,n);
                    //printf("Rows[%d+1] = %d, n = %d\n",c, Rows[c+1], n);
                    //printf("block (%d, %d)\n", std::get<1>(Array[i]), std::get<0>(Array[i]));
                    std::get<0>(negTrans->Array[n])=std::get<1>(Array[i]);
                    std::get<1>(negTrans->Array[n])=std::get<0>(Array[i]);
                    std::get<2>(negTrans->Array[n]) = -std::get<2>(Array[i]);
                    //std::get<2>(Array[i])->printFullMatrix();
                    //printf("finished c=%d, i=%d, n=%d\n",c, i,n);
                    n++;
                }
            }
        //}
    }
    return negTrans;
}

void COO::printFullMatrix()
{
    std::cout << "\nFull Dense Expansion (" << Num_Rows << "x" << Num_Cols << ")\n";
    for (int i = 0; i < Num_Rows; i++) {
        for (int j = 0; j < Num_Cols; j++)
        {
            std::cout << std::setw(6) << this->operator()(i,j);
        }
        std::cout << "\n";
    }
}


int countvalues(const Matrix* input)
{
    int numvals=0;

    if (const BlockToeplitz* bttb = dynamic_cast<const BlockToeplitz*>(input))//Checks if it is BlockToeplitz
    {
        int diag_length,d,num_subrows,num_subcols,num_rowblocks,num_colblocks;
        num_subrows = bttb->Vals[0]->rows();
        num_subcols = bttb->Vals[0]->cols();
        num_rowblocks=bttb->rows()/num_subrows;
        num_colblocks=bttb->cols()/num_subcols;
        for(int i=0;i<bttb->Num_Diags;i++)
        {
            d=bttb->Diags[i];
            if(d>=0)
            {
                diag_length=std::min(num_rowblocks, num_colblocks-d);
            }
            else
            {
                diag_length=std::min(num_colblocks, num_rowblocks+d);
            }
            
            numvals+=diag_length*countvalues(bttb->Vals[i]);
        }
        return numvals;

    }
    else if (const SparseToeplitz* toep = dynamic_cast<const SparseToeplitz*>(input))//Checks if it is SparseToeplitz
    {
        int diag_length,d;
        for(int i=0;i<toep->Num_Diags;i++)
        {
            d=toep->Diags[i];
            if(d>=0)
            {
                diag_length=std::min(toep->rows(), toep->cols()-d);
            }
            else
            {
                diag_length=std::min(toep->cols(), toep->rows()+d);
            }
            numvals+=diag_length;
        }
        return numvals;
    }
    else
    {
        throw std::invalid_argument("The conversion function only works for BTTB matrixes");
    }
}


void setvalues(const Matrix* input,tuple* values, int& array_pos,int matrixpos_row,int matrixpos_col)
{
    if (const BlockToeplitz* bttb = dynamic_cast<const BlockToeplitz*>(input))
    {
        int d,diag_length,col_pos,row_pos,num_subrows,num_subcols,num_rowblocks,num_colblocks;
        num_subrows=(bttb->Vals[0])->rows();
        num_subcols=(bttb->Vals[0])->cols();
        num_rowblocks=bttb->rows()/num_subrows;
        num_colblocks=bttb->cols()/num_subcols;
        for(int i=0;i<bttb->Num_Diags;i++)
        {
            d=bttb->Diags[i];
            Matrix* submatrix=bttb->Vals[i];

            if(d>=0)
            {
                row_pos=matrixpos_row;
                col_pos=matrixpos_col+d*num_subcols;
                diag_length=std::min(num_rowblocks, num_colblocks-d);
                for(int j=0;j<diag_length;j++)
                {
                    setvalues(submatrix,values,array_pos,row_pos,col_pos);
                    row_pos+=num_subrows;
                    col_pos+=num_subcols;
                }
            }
            else
            {
                row_pos=matrixpos_row-d*num_subrows;
                col_pos=matrixpos_col;
                diag_length=std::min(num_colblocks, num_rowblocks+d);
                for(int j=0;j<diag_length;j++)
                {
                    setvalues(submatrix,values,array_pos,row_pos,col_pos);
                    row_pos+=num_subrows;
                    col_pos+=num_subcols;
                }
                
            }
        }

    }
    else if (const SparseToeplitz* toep = dynamic_cast<const SparseToeplitz*>(input))
    {
        int d,val,diag_length,col_pos,row_pos;
        for(int i=0;i<toep->Num_Diags;i++)
        {
            val=toep->Vals[i];
            d=toep->Diags[i];
            if(d>=0)
            {
                row_pos=matrixpos_row;
                col_pos=matrixpos_col+d;
                diag_length=std::min(toep->rows(), toep->cols()-d);
                for(int j=0;j<diag_length;j++)
                {
                    values[array_pos]=std::tuple(row_pos,col_pos,val);
                    array_pos+=1;
                    row_pos+=1;
                    col_pos+=1;
                }
            }
            else
            {
                row_pos=matrixpos_row-d;
                col_pos=matrixpos_col;
                diag_length=std::min(toep->cols(), toep->rows()+d);
                for(int j=0;j<diag_length;j++)
                {
                    values[array_pos]=std::tuple(row_pos,col_pos,val);
                    array_pos+=1;
                    row_pos+=1;
                    col_pos+=1;
                }
            }
        }
    }
    else
    {
        throw std::invalid_argument("The conversion function only works for BTTB matrixes");
    }
}

COO::COO(const BlockToeplitz* BT)//BTTB conversion algoritm, individual blocks must be toeplitz
{
    Num_Rows=BT->rows();
    Num_Cols=BT->cols();
    Num_Vals=countvalues(BT);
    Array = new tuple[Num_Vals]; 
    int start_array_pos=0;
    setvalues(BT,Array,start_array_pos,0,0);
}