#include "Laplacian3d.h"

Laplacian3D_ToeplitzMatrix::Laplacian3D_ToeplitzMatrix(int rows_in, int cols_in,int arrays_in)
    : rows(rows_in),
      cols(cols_in),
      arrays(arrays_in)
{
}
    
Laplacian3D_ToeplitzMatrix::~Laplacian3D_ToeplitzMatrix()
{



}


double Laplacian3D_ToeplitzMatrix::k_func(double x, double y, double z) {
    // Example variable k function; modify as needed
    return 1.0;
}

void Laplacian3D_ToeplitzMatrix::Generate_Toeplitz()
{
    // Implementation for generating the Laplacian matrix with non-homogeneous mesh spacing and variable k


    // 1.)Upper incidence matrix generation (2D)
    //     a.) Row block matrix generation
    SparseToeplitz rowBlockMatrix = SparseToeplitz(cols, cols, 3); //leaf row block matrix with 3 diagonals
    rowBlockMatrix.Diags[0] = -(cols - 1);
    rowBlockMatrix.Diags[1] = 0;
    rowBlockMatrix.Diags[2] = 1;
    rowBlockMatrix.Vals[0] = 1;
    rowBlockMatrix.Vals[1] = -1;
    rowBlockMatrix.Vals[2] = 1;

    //     b.) Identity matrix generation for upper incidence matrix
    SparseToeplitz identityMatrixRows = SparseToeplitz(rows, rows, 1); //leaf identity matrix
    identityMatrixRows.Diags[0] = 0;
    identityMatrixRows.Vals[0] = 1;

    //     c.) Identity matrix (rows) kronecker product with row block matrix
    Matrix* upperIncidenceMatrix = identityMatrixRows.Kronecker(rowBlockMatrix); // upper incidence matrix
    BlockToeplitz* rowBlockPtr = static_cast<BlockToeplitz*>(upperIncidenceMatrix);  //cast to BlockToeplitz pointer for further operations


    // 2.) Lower incidence matrix generation (2D)
    //     a.) Column block matrix generation
    SparseToeplitz columnBlockMatrix(rows, rows, 3); //leaf column block matrix with 3 diagonals
    columnBlockMatrix.Diags[0] = -(rows - 1);
    columnBlockMatrix.Diags[1] = 0;
    columnBlockMatrix.Diags[2] = 1;
    columnBlockMatrix.Vals[0] = 1;
    columnBlockMatrix.Vals[1] = -1;
    columnBlockMatrix.Vals[2] = 1;

    //     b.) Identity matrix generation for lower incidence matrix
    SparseToeplitz identityMatrixCols(cols, cols, 1); //leaf identity matrix
    identityMatrixCols.Diags[0] = 0;
    identityMatrixCols.Vals[0] = 1;

    //     c.) Column block matrix kronecker product with identity matrix (cols)
    Matrix* lowerIncidenceMatrix = columnBlockMatrix.Kronecker(identityMatrixCols); // lower incidence matrix
    BlockToeplitz* lowerIncidencePtr = static_cast<BlockToeplitz*>(lowerIncidenceMatrix);  //cast to BlockToeplitz pointer for further operations


    // 3.) Lower incidence matrix generation (3D)
    //     a.) Array block matrix generation
    SparseToeplitz arrayBlockMatrix(arrays, arrays, 3); //leaf array block matrix with 3 diagonals
    arrayBlockMatrix.Diags[0] = -(arrays - 1);
    arrayBlockMatrix.Diags[1] = 0;
    arrayBlockMatrix.Diags[2] = 1;
    arrayBlockMatrix.Vals[0] = 1;
    arrayBlockMatrix.Vals[1] = -1;
    arrayBlockMatrix.Vals[2] = 1;

    //     b.) Identity matrix generation for lower incidence matrix
    SparseToeplitz identityMatrixArrays(arrays, arrays, 1); //leaf identity matrix
    identityMatrixArrays.Diags[0] = 0;
    identityMatrixArrays.Vals[0] = 1;
    SparseToeplitz identityMatrix_2D(rows*cols, rows*cols, 1);
    identityMatrix_2D.Diags[0] = 0;
    identityMatrix_2D.Vals[0] = 1;

    //     c.) Column block matrix kronecker product with identity matrix (arrays)
    lowerIncidenceMatrix_3D =static_cast<BlockToeplitz*>( (arrayBlockMatrix.Kronecker(identityMatrix_2D))); // lower incidence matrix
    //BlockToeplitz* lowerIncidencePtr_3D = lowerIncidenceMatrix_3D);  //cast to BlockToeplitz pointer for further operations
    //lowerIncidenceMatrix_3D = lowerIncidencePtr_3D->Clone(1.0);



    // 4.) Final Laplacian matrix assembly
    //     a.) Concatenate upper and lower incidence matrices
    int ndiags = 2; //number of diagonals in incidence matrix
    BlockToeplitz IncidenceMatrix_2D(rows * cols * 2, rows * cols, ndiags); // incidence matrix with 2 block rows
    IncidenceMatrix_2D.Diags[0] = 0; // diagonal for upper incidence matrix
    IncidenceMatrix_2D.Diags[1] = -1; // diagonal for lower incidence matrix
    IncidenceMatrix_2D.Vals[0] = rowBlockPtr;
    IncidenceMatrix_2D.Vals[1] = lowerIncidencePtr;
    //Incidence=&IncidenceMatrix;

    //IncidenceMatrix_2D.printFullMatrix();

    upperIncidenceMatrix_3D = static_cast<BlockToeplitz*>(identityMatrixArrays.Kronecker(IncidenceMatrix_2D)); // upper incidence matrix

    //BlockToeplitz* BlockPtr_2D = static_cast<BlockToeplitz*>(upperIncidenceMatrix_3D);  //cast to BlockToeplitz pointer for further operations
    //BlockPtr_2D->printFullMatrix();
    //upperIncidenceMatrix_3D = BlockPtr_2D->Clone(1.0);
    
    //BlockToeplitz IncidenceMatrix_3D(rows * cols * arrays * 3, rows * cols * arrays, ndiags); // incidence matrix with 2 block rows
    //IncidenceMatrix_3D.Diags[0] = 0; // diagonal for upper incidence matrix
    //IncidenceMatrix_3D.Diags[1] = -1; // diagonal for lower incidence matrix
    //IncidenceMatrix_3D.Vals[0] = BlockPtr_2D;
    //IncidenceMatrix_3D.Vals[1] = lowerIncidencePtr_3D;

    //leftIncidenceT_Matrix_3D = ;

    leftIncidenceT_Matrix_3D = static_cast<BlockToeplitz*>(upperIncidenceMatrix_3D->negativeTranspose());

    //leftIncidenceT_Matrix_3D = left_T_3D->Clone(1.0);

    rightIncidenceT_Matrix_3D = static_cast<BlockToeplitz*>(lowerIncidenceMatrix_3D->negativeTranspose());

    
    //     b.) Compute negative transpose
    //Incidence=IncidenceMatrix_3D.Clone(1.0);
    //Incidence->printFullMatrix(); //This print also returns an error because of inconsistent block sizes
    //Matrix* negTransPtr = IncidenceMatrix_3D.negativeTranspose();
    //BlockToeplitz negTrans=*negTrans;
    //Incidence_T=negTransPtr;
    //BlockToeplitz* negTransBlockPtr = static_cast<BlockToeplitz*>(negTransPtr); //cast to BlockToeplitz pointer for further operations

    //     c.) W_ee matrix generation function
    int dim = 3 * rows * cols * arrays;



    Diagonal=new DiagonalMatrix(dim);

double dx = 1.0 / cols;
double dy = 1.0 / rows;
double dz = 1.0 / arrays;

int N = cols * rows * arrays;
int Nx=cols;
int Ny=rows;
int Nz=arrays;

for (int i = 0; i < dim; ++i)
{
    int node = i % N;

    int col = node % Nx;
    int row = (node / Nx) % Ny;
    int arr = node / (Nx * Ny);

    double x = col * dx;
    double y = row * dy;
    double z = arr * dz;

    double k_val = k_func(x, y, z);

    if (i < N)
    {
        // x-directed edges
        Diagonal->Diag_Vals[i] = k_val / (dx * dx);
    }
    else if (i < 2 * N)
    {
        // y-directed edges
        Diagonal->Diag_Vals[i] = k_val / (dy * dy);
    }
    else
    {
        // z-directed edges
        Diagonal->Diag_Vals[i] = k_val / (dz * dz);
    }
}




    Tmp1= Vectord(upperIncidenceMatrix_3D->rows()+lowerIncidenceMatrix_3D->rows());
    Tmp2=Vectord(upperIncidenceMatrix_3D->rows()+lowerIncidenceMatrix_3D->rows());
}

void Laplacian3D_ToeplitzMatrix::Laplacian_Toeplitz(const Vectord& input,Vectord& result)
{

    upperIncidenceMatrix_3D->MatMulAdd(input,0,Tmp1,0);

    lowerIncidenceMatrix_3D->MatMulAdd(input,0,Tmp1,upperIncidenceMatrix_3D->rows());

    Diagonal->MatMul(Tmp1,Tmp2);

    leftIncidenceT_Matrix_3D->MatMulAdd(Tmp2,0,result,0);

    rightIncidenceT_Matrix_3D->MatMulAdd(Tmp2,leftIncidenceT_Matrix_3D->cols(),result,0);
    for(int i=0;i<Tmp1.len();i++)
    {
        Tmp1[i]=0.0;
    }
}

void Laplacian3D_ToeplitzMatrix::Laplacian_COO(const Vectord& input,Vectord& result)
{
    U_I_3D_COO->MatMulAdd(input,0,Tmp1,0);
    L_I_3D_COO->MatMulAdd(input,0,Tmp1,upperIncidenceMatrix_3D->rows());
    Diagonal->MatMul(Tmp1,Tmp2);
    L_I_3D_COO->MatMulAdd(Tmp2,0,result,0);
    R_I_T_3D_COO->MatMulAdd(Tmp2,leftIncidenceT_Matrix_3D->cols(),result,0);
    for(int i=0;i<Tmp1.len();i++)
    {
        Tmp1[i]=0.0;
    }
}

void Laplacian3D_ToeplitzMatrix::Laplacian_CSR(const Vectord& input,Vectord& result)
{
    U_I_3D_CSR->MatMulAdd(input,0,Tmp1,0);
    L_I_3D_CSR->MatMulAdd(input,0,Tmp1,upperIncidenceMatrix_3D->rows());
    Diagonal->MatMul(Tmp1,Tmp2);
    L_I_3D_CSR->MatMulAdd(Tmp2,0,result,0);
    R_I_T_3D_CSR->MatMulAdd(Tmp2,leftIncidenceT_Matrix_3D->cols(),result,0);
    for(int i=0;i<Tmp1.len();i++)
    {
        Tmp1[i]=0.0;
    }
}





void Laplacian3D_ToeplitzMatrix::Generate_COO()
{
    Generate_Toeplitz();
    U_I_3D_COO=new COO(upperIncidenceMatrix_3D);
    L_I_3D_COO=new COO(lowerIncidenceMatrix_3D);
    L_I_T_3D_COO=new COO(leftIncidenceT_Matrix_3D);
    R_I_T_3D_COO=new COO(rightIncidenceT_Matrix_3D);
    delete upperIncidenceMatrix_3D;
    delete lowerIncidenceMatrix_3D;
    delete leftIncidenceT_Matrix_3D;
    delete rightIncidenceT_Matrix_3D;
}

void Laplacian3D_ToeplitzMatrix::Generate_CSR()
{
    Generate_COO();
    
    U_I_3D_CSR=new CSR(U_I_3D_COO);
    L_I_3D_CSR=new CSR(L_I_3D_COO);
    L_I_T_3D_CSR=new CSR(L_I_T_3D_COO);
    R_I_T_3D_CSR=new CSR(R_I_T_3D_COO);
    delete U_I_3D_COO;
    delete L_I_3D_COO;
    delete L_I_T_3D_COO;
    delete R_I_T_3D_COO;
    
    
}





