#pragma once

#include <fstream>
#include <string>
#include "Laplacian2d.h"
#include "ForwardEuler.h"
//#include "Laplacian2d_CSR.h"
//#include "Laplacian2d_COO.h"