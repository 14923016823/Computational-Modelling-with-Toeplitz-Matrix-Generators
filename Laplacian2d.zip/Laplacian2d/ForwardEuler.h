#pragma once
#include "Laplacian2d.h"

class ForwardEulerSolver {
public:
    ForwardEulerSolver(Laplacian2D_ToeplitzMatrix& lap);

    void solve(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;
    void solvecsr(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;
    void solvecoo(
        Vectord& u,          // in-place solution
        double dt,
        int numSteps
    ) const;

private:
     Laplacian2D_ToeplitzMatrix& L;
};
