#include "ForwardEuler.h"

ForwardEulerSolver::ForwardEulerSolver(Laplacian2D_ToeplitzMatrix& lap)
    : L(lap)
{}

void ForwardEulerSolver::solve(Vectord& u, double dt, int numSteps) const
{
    Vectord Lu(u.len());

    for (int step = 0; step < numSteps; ++step)
    {
        L.Laplacian2d(u, Lu);      // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }
}

void ForwardEulerSolver::solvecoo(Vectord& u, double dt, int numSteps) const
{
    COO laplacioncoo=L.COO_Laplacian();
    Vectord Lu(u.len());

    for (int step = 0; step < numSteps; ++step)
    {
        laplacioncoo.MatMul(u, Lu);      // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }
}

void ForwardEulerSolver::solvecsr(Vectord& u, double dt, int numSteps) const
{
    CSR laplacioncsr=L.CSR_Laplacian();
    Vectord Lu(u.len());

    for (int step = 0; step < numSteps; ++step)
    {
        laplacioncsr.MatMul(u, Lu);    // Lu = L(u)
        u.axpy(dt, Lu);      // u += dt * Lu
    }
}


