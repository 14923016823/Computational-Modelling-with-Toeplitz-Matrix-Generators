#include "Other.h"


void initializeGaussian(Vectord& state,int h,int w,double amplitude,double sigma)
{
    double ic = 0.5 * (h - 1);
    double jc = 0.5 * (w - 1);

    double twoSigma2 = 2.0 * sigma * sigma;

    for (int i = 0; i < h; i++)
    {
        for (int j = 0; j < w; j++)
        {
            double di = i - ic;
            double dj = j - jc;

            double r2 = di * di + dj * dj;
            state[i * w + j] =
                amplitude * std::exp(-r2 / twoSigma2);
        }
    }
}
void writeStateToFile(
    const std::string& filename,
    const Vectord& state,
    int h,
    int w
)
{
    if (state.len() != static_cast<std::size_t>(h * w))
        throw std::invalid_argument("State size does not match h * w");

    std::ofstream out(filename);
    if (!out)
        throw std::runtime_error("Failed to open output file");

    out.precision(16);
    out.setf(std::ios::scientific);

    // Write as a single column vector (lexicographic order)
    for (std::size_t i = 0; i < state.len(); ++i)
        out << state[i] << '\n';

    out.close();
}


int main()
{


    int rows = 50;
    int cols = 50;


    Vectord vec(cols*rows);
    initializeGaussian(vec, rows, cols, 2.0, 10.0);
    std::cout<<"writing start to file";
    writeStateToFile("start_state.dat", vec, rows, cols);

    

    

    //Laplacian2D_FullMatrix laplacian(rows, cols);
    std::cout<<"generating matries";

    Laplacian2D_ToeplitzMatrix L2d=Laplacian2D_ToeplitzMatrix(rows,cols);
    ForwardEulerSolver solver=ForwardEulerSolver(L2d);
    std::cout<<"calculating";
    solver.solvecoo(vec,1e-6,10);
    std::cout<<"writing middle to file";
    writeStateToFile("mid_state.dat", vec, rows, cols);
    //solver.solvecoo(vec,1e-5,900);
    //std::cout<<"writing end to file";
    

    //writeStateToFile("end_state.dat", vec, rows, cols);


    return 0;
}